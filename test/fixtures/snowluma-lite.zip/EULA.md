fake eula
